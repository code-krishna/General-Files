1. Install python3 in your system. 
Install using the link - https://www.python.org/ftp/python/3.7.0/python-3.7.0-macosx10.6.pkg
(To check use '$python3' command in your terminal and 'control + D' to exit it)

2. Run the 'Installation.sh' bash for installing depenencies required for this program to run using command - '$ bash Installation.sh'

3. Open 'MyFile.xml' in a new editor window and edit the values as per requirement of 

-Change number of users:
 (i)GD users, (ii)Aacmi users and (iii)Gateway users 

-Change Gateway version:
  Edit the <AuthVersion> field using 0,1 or 3 for V0,V1 or V3.

 -Change PackageID and AppID
  (i)Edit <Package> filed in the format (PackageID,AppID) 
  (ii)More than one (PackageID,AppID) can be added seperated by space

4. Finally run the bash file 'DatamiFramework.sh' using command - '$ bash DatamiFramework.sh'