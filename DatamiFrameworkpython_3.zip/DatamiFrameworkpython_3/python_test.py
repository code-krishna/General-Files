strArray = "(1,Hi) (2,3) (4,5)"
strArray = strArray.split()
for pck in strArray:
	print(pck.strip('()'))
	pck = pck.strip('()')
	mypck = pck.split(',')
	print(mypck[1])