'''
--------------------------------------------
Framework designed by Vamsi Krishna Pendyala
Summer intern 2018 Datami Mobile Soulutons
--------------------------------------------
'''

import requests
import sys
import json
import socket
import binascii
import pickle
import base64
import time
import hashlib
from array import *
from random import randint 
import unittest


class GD_Variable:
	urlD = ''
	HeaderD = {}
	bodyD = {}

	def __init__(self, uid):
	 with open('GD_Call.json') as f:
	 	data = json.load(f)
	 self.urlD = data["url"]
	 self.HeaderD = data["Header"]
	 data["Body"]["uid"] = uid
	 #data["Body"]["auth"]["packageCode"]=pck
	 self.bodyD = data["Body"]
	 f.close()

class Aacmi_Variable:
	urlD = ''
	HeaderD = {}
	bodyD = {}

	def __init__(self, urlID,uid):
	 with open('Aacmi_Call.json') as f:
	 	data = json.load(f)
	 data["Body"]["auth"]["deviceId"]["uid"] = uid
	 self.urlD = urlID + '/v1/sd/int/authorize'
	 self.HeaderD = data["Header"]
	 self.bodyD = data["Body"]
	 f.close()

'''
class V0Auth_Packet:
	AUTH_REQUEST = 0
	VER_ZERO = 0
	token = ""
	sig = ""


	def__init__(self,AUTH_REQUEST, VER_ZERO, token, sig, socket):
	 self.AU

'''