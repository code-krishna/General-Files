import io

str1 = "Hello World"

str1 = io.BytesIO(bytes(str1,'utf-8')) 
print(str1.read(4))