<?php
if ($_GET['run']) {
  # This code will run if ?run=true is set.
  exec("cd Desktop");
  exec("cd DatamiFrameworkpython_3");
  exec("pytest --html=report.html")
}
?>

<!-- This link will add ?run=true to your URL, myfilename.php?run=true -->
<a href="?run=true">Click Me!</a>