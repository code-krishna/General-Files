#!/bin/bash
cd
pip3 install six
pip3 install future
pip3 install asyncio
pip3 install aiohttp
pip3 install pytest
pip3 install pytest-html
ulimit -a
ulimit -Sn 10000