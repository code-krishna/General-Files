#!/bin/bash
pytest --html=report.html --self-contained-html
open -a "Safari" report.html