import requests
import sys
import json
import socket
import binascii
import pickle
import base64
import time
import hashlib
from array import *
from random import randint 
import unittest
unittest.TestLoader.sortTestMethodsUsing = None
from Variables import GD_Variable, Aacmi_Variable
from Helpers import Callers
import xml.dom.minidom as minidom  
import asyncio
import aiohttp
import math
import pytest

messages={}
tokens = []
uids = {}


async def asynchronous_GDCall(doc):
  caller = Callers()
  exception = False
  #doc = minidom.parse("MyFile.xml")
  nusers = doc.getElementsByTagName("usersGD")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncGD(uid)) for uid in users]
  await asyncio.wait(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AacmiCall(doc,pck):
  caller = Callers()
  exception = False
  nusers = doc.getElementsByTagName("usersAacmi")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncAacmi(uid,pck)) for uid in users]
  await asyncio.wait(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AuthCall(loop,doc,pck):
  caller = Callers()
  exception = False
  nusers = doc.getElementsByTagName("usersAuth")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  ver = doc.getElementsByTagName("AuthVersion")
  for n in ver:
    version = int(n.getAttribute("version"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncAuthCall(uid,version,loop,pck,tokens,messages,uids)) for uid in users]
  await asyncio.wait(tasks)
  print(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AuthTest(loop):
  start = time.time()
  caller = Callers()
  #client,addr = await loop.sock_accept(s)
  '''
  print("________________")
  print("Tokens and messages: ")
  for token in tokens:
    print("Token: {}, Message: {}".format(token,messages[token]))
  '''
  i=0
  for j in range(0,math.ceil(len(tokens)/10)):
    if(i+10 > len(tokens)):
      print("Packets going to be sent: ")
      print(tokens[i:len(messages)])
      tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop,uids)) for token in tokens[i:len(messages)]]
      await asyncio.wait(tasks)
      i=0
      for task in tasks:
        if("Exception!" in str(task)):
          print(task)
          exception = True
          i+=1
      print("Process took: {:.2f} seconds".format(time.time() - start))
      i+=len(messages)
    else:
      print("Packets going to be sent: ")
      print(tokens[i:i+10])
      tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop,uids)) for token in tokens[i:i+10]]
      await asyncio.wait(tasks)
      i=0
      for task in tasks:
        if("Exception!" in str(task)):
          print(task)
          exception = True
          i+=1
      print("Process took: {:.2f} seconds".format(time.time() - start))
      i+=10
      
  #tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop)) for token in tokens]
  #await asyncio.wait(tasks)
  #s.close()

class TestGateway(unittest.TestCase):

 @classmethod
 def setUpClass(cls):
  print("Setup started")
 
 #@pytest.mark.skip(reason="It's complicated :(")
 def test_1GDCall(self):
  doc = minidom.parse("MyFile.xml")
  print('Asynchronous:')
  ioloop = asyncio.get_event_loop()
  exception, num=ioloop.run_until_complete(asynchronous_GDCall(doc))
  self.assertEqual(exception,False, "----Exception occured in GD and number of exceptions: {}----".format(num))
  #ioloop.close()

 #@pytest.mark.skip(reason="It's complicated :(")
 def test_2AacmiCall(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
    #print("HEY YOU!!")
  for pck in pckgID:
    if(pck!=" "):
      print('---------Asynchronous for Package :{}----------'.format(pck))
      ioloop = asyncio.get_event_loop()
      exception, num=ioloop.run_until_complete(asynchronous_AacmiCall(doc,pck))
      self.assertEqual(exception,False, "-----Exception occured in Aacmi and number of exceptions: {}------".format(num))
  #ioloop.close()
  
 def test_3GatewayCall(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
  for pck in pckgID:
    if(pck!=" "):
      print('---------Asynchronous for Package :{}-----------'.format(pck))
      ioloop = asyncio.get_event_loop()
      messages.clear()
      tokens.clear()
      exception, num=ioloop.run_until_complete(asynchronous_AuthCall(ioloop,doc,pck))
      self.assertEqual(exception,False, "------Exception occured in AuthCall during packet creation and number of exceptions: {}------".format(num))
      ioloop.run_until_complete(asynchronous_AuthTest(ioloop))
  #ioloop.close()
  '''

 def test_4AuthTest(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
    print("HEY YOU!!")
    print(n)
  for pck in pckgID:
    if(pck!=" "):
      print('Asynchronous:')
      ioloop = asyncio.get_event_loop()
      ioloop.run_until_complete(asynchronous_AuthTest(ioloop))
  ioloop.close()
  '''
 @classmethod
 def tearDownClass(cls):
   print("Tear Down started")

#suite = unittest.TestLoader().loadTestsFromTestCase(TestGateway)
#unittest.TextTestRunner(verbosity=2).run(suite)
