'''
--------------------------------------------
Framework designed by Vamsi Krishna Pendyala
Summer intern 2018 Datami Mobile Soulutons
--------------------------------------------
'''
import datetime
import time
import requests
import sys
import json
import socket
import binascii
import pickle
import base64
import time
import hashlib
from array import *
from random import randint 
import unittest
unittest.TestLoader.sortTestMethodsUsing = None
from Variables import GD_Variable, Aacmi_Variable
from Helpers import Callers
import xml.dom.minidom as minidom  
import asyncio
import aiohttp
import math
import pytest

messages={}
tokens = []
uids = {}

async def asynchronous_GDCall(doc):
  caller = Callers()
  exception = False
  #doc = minidom.parse("MyFile.xml")
  nusers = doc.getElementsByTagName("usersGD")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncGD(uid)) for uid in users]
  await asyncio.wait(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AacmiCall(doc):
  caller = Callers()
  exception = False
  nusers = doc.getElementsByTagName("usersAacmi")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncAacmi(uid)) for uid in users]
  await asyncio.wait(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AuthCall(loop,doc):
  caller = Callers()
  exception = False
  nusers = doc.getElementsByTagName("usersGateway")
  for n in nusers:
    no_users = int(n.getAttribute("users"))
  ver = doc.getElementsByTagName("AuthVersion")
  for n in ver:
    version = int(n.getAttribute("version"))
  users = caller.GetUsers(no_users)
  start = time.time()
  tasks = [asyncio.ensure_future(caller.fetch_asyncAuthCall(uid,version,loop,tokens,messages,uids)) for uid in users]
  await asyncio.wait(tasks)
  print(tasks)
  i=0
  for task in tasks:
    if("Exception" in str(task)):
      print(task)
      exception = True
      i+=1
  print("Process took: {:.2f} seconds".format(time.time() - start))
  return exception,i

async def asynchronous_AuthTest(loop):
  start = time.time()
  caller = Callers()
  exception = False
  GDCall = GD_Variable("3c8c34a2")
  print("-----------------")
  print("GD_Request: UID = {}, URL = {}, BODY = {}, HEADER = {} ".format("3c8c34a2",GDCall.urlD, json.dumps(GDCall.bodyD), GDCall.HeaderD))
  print("-----------------")
  print('Fetch async GD_process {} started'.format("3c8c34a2"))
  post_response = requests.post(GDCall.urlD, data=json.dumps(GDCall.bodyD), headers=GDCall.HeaderD)
  if('qin' in str(post_response.json()['services']['aacmi'])):
    deployment = 'qin'
  else:
    deployment = 'stgin'
  #client,addr = await loop.sock_accept(s)
  '''
  print("________________")
  print("Tokens and messages: ")
  for token in tokens:
    print("Token: {}, Message: {}".format(token,messages[token]))
  '''
  i=0
  p=0
  for j in range(0,math.ceil(len(tokens)/10)):
    if(i+10 > len(tokens)):
      print("Packets going to be sent: ")
      print(tokens[i:len(messages)])
      tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop,uids,deployment)) for token in tokens[i:len(messages)]]
      await asyncio.wait(tasks)
      i=0
      for task in tasks:
        if("Exception" in str(task)):
          print(task)
          exception = True
          i+=1
      print("Process took: {:.2f} seconds".format(time.time() - start))
      i+=len(messages)
    else:
      print("Packets going to be sent: ")
      print(tokens[i:i+10])
      tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop,uids,deployment)) for token in tokens[i:i+10]]
      await asyncio.wait(tasks)
      i=0
      for task in tasks:
        if("Exception" in str(task)):
          print(task)
          exception = True
          p+=1
      print("Process took: {:.2f} seconds".format(time.time() - start))
      i+=10
  return exception,p   
  #tasks = [asyncio.ensure_future(caller.async_AuthTest(messages[token],token,loop,uids,deployment,++i)) for token in tokens]
  #await asyncio.wait(tasks)
  #return exception,p
  #s.close()

class TestGateway(unittest.TestCase):

 @classmethod
 def setUpClass(cls):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
    #print("HEY YOU!!")
  pckgID = pckgID.split()
  for pck in pckgID:
    pck = pck.strip('()')
    pck = pck.split(',')
    caller = Callers()
    exception = False
    GDCall = GD_Variable("3c8c34a2")
    post_response = requests.post(GDCall.urlD, data=json.dumps(GDCall.bodyD), headers=GDCall.HeaderD)
    if('qin' in str(post_response.json()['services']['aacmi'])):
      deployment = 'qin'
    else:
      deployment = 'stgin'
    print("Setup started for package: {}".format(pck[0]))
    now = datetime.datetime.now()
    with open('Aacmi_Call.json') as f:
      data = json.load(f)
    urlDAS = 'http://'+deployment+'-api.cloudmi.datami.com/das/zmi-accounting/v1/package/'+pck[0]+'/user/'+ '3c8c34a2' +'/year/'+str(now.year)+'/month/'+str(now.month)+'/day/'+str(now.day)
    response = requests.get(urlDAS)
    print("Das initial hit response: {}".format(response))
    time.sleep(1)
  
 
 #@pytest.mark.skip(reason="It's complicated :(")
 def test_1GDCall(self):
  doc = minidom.parse("MyFile.xml")
  print('Asynchronous:')
  ioloop = asyncio.get_event_loop()
  exception, num=ioloop.run_until_complete(asynchronous_GDCall(doc))
  self.assertEqual(exception,False, "----Exception occured in GD and number of exceptions: {}----".format(num))
  #ioloop.close()

 #@pytest.mark.skip(reason="It's complicated :(")
 def test_2AacmiCall(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
    #print("HEY YOU!!")
  pckgID = pckgID.split()
  for pck in pckgID:
    pck = pck.strip('()')
    pck = pck.split(',')
    print('---------Asynchronous for Package: {}, AppID: {}-----------'.format(pck[0],pck[1]))
    with open('GD_Call.json') as f:
      data = json.load(f)
    data["Body"]["appId"] = pck[1]
    jsonFile = open("GD_Call.json", "w+")
    jsonFile.write(json.dumps(data))
    jsonFile.close()
    with open('Aacmi_Call.json') as f:
      data = json.load(f)
    data["Body"]["auth"]["appId"] = pck[1]
    data["Body"]["auth"]["packageCode"] = pck[0]
    jsonFile = open("Aacmi_Call.json", "w+")
    jsonFile.write(json.dumps(data))
    jsonFile.close()
    ioloop = asyncio.get_event_loop()
    exception, num=ioloop.run_until_complete(asynchronous_AacmiCall(doc))
    self.assertEqual(exception,False, "-----Exception occured in Aacmi and number of exceptions: {}------".format(num))
  
 def test_3GatewayCall(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
  pckgID = pckgID.split()
  for pck in pckgID:
    pck = pck.strip('()')
    pck = pck.split(',')
    print('---------Asynchronous for Package: {}, AppID: {}-----------'.format(pck[0],pck[1]))
    with open('GD_Call.json',) as f:
      data = json.load(f)
    data["Body"]["appId"] = pck[1]
    jsonFile = open("GD_Call.json", "w+")
    jsonFile.write(json.dumps(data))
    jsonFile.close()
    with open('Aacmi_Call.json') as f:
      data = json.load(f)
    data["Body"]["auth"]["packageCode"] = pck[0]
    data["Body"]["auth"]["appId"] = pck[1]
    jsonFile = open("Aacmi_Call.json", "w+")
    jsonFile.write(json.dumps(data))
    jsonFile.close()
    print(data)
    ioloop = asyncio.get_event_loop()
    messages.clear()
    tokens.clear()
    exception, num=ioloop.run_until_complete(asynchronous_AuthCall(ioloop,doc))
    exception1, num1=ioloop.run_until_complete(asynchronous_AuthTest(ioloop))
    self.assertEqual(exception1,False, "------Exception occured in AuthTest and number of exceptions: {}------".format(num1))
    self.assertEqual(exception,False, "------Exception occured in AuthCall during packet creation and number of exceptions: {}------".format(num))
  #ioloop.close()
  '''

 def test_4AuthTest(self):
  doc = minidom.parse("MyFile.xml")
  pack = doc.getElementsByTagName("Package")
  for n in pack:
    pckgID = n.getAttribute("PckgID")
    print("HEY YOU!!")
    print(n)
  for pck in pckgID:
    if(pck!=" "):
      print('Asynchronous:')
      ioloop = asyncio.get_event_loop()
      ioloop.run_until_complete(asynchronous_AuthTest(ioloop))
  ioloop.close()
  '''
 @classmethod
 def tearDownClass(cls):
   print("Tear Down started")

#suite = unittest.TestLoader().loadTestsFromTestCase(TestGateway)
#unittest.TextTestRunner(verbosity=2).run(suite)
